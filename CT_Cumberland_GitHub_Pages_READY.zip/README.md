# CT Cumberland Control Total

GitHub Pages ready.

Deploy:
1. Upload `index.html` and `.nojekyll` to the repository root.
2. GitHub repository > Settings > Pages.
3. Source: Deploy from a branch.
4. Branch: main.
5. Folder: /(root).
6. Save.
